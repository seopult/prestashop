<?php
/**
 * 2015 SeoPult
 *
 * @author    SeoPult RU <https://seopult.ru/>
 * @copyright 2015 SeoPult RU
 * @license   GNU General Public License, version 2
 */

if (!defined('_PS_VERSION_'))
	exit;

/**
 * Function used to update your module from previous versions to the version 1.1,
 * Don't forget to create one file per version.
 */
function upgrade_module_1_1_0($module)
{
	/**
	 * Do everything you want right there,
	 * You could add a column in one of your module's tables
	 */

	return $module;
}
